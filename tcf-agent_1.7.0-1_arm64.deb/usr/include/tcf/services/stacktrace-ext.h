/*
 * Extension point definitions for stacktrace.c.
 *
 * TRACE_STACK_BOTTOM_CHECK - check stack trace bottom limit
 */

#define TRACE_STACK_BOTTOM_CHECK do {} while(0)
